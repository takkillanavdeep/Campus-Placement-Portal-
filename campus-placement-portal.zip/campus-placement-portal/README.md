# Campus Placement & Internship Portal

Role-based, multi-page placement portal (Node.js, Express, SQLite). Pages are server-rendered, and all permission and eligibility checks run on the server.

## Roles
| Role | Capabilities |
|---|---|
| **Student** | Browse approved openings, manage profile (branch, CGPA, grad year, resume link), apply, track status (page auto-refreshes every 15s) |
| **Recruiter** | Create company profile, post jobs with min CGPA and allowed branches, review applicant profiles, update status for one or many applicants |
| **Admin** | Approve or reject companies and job postings; audit log with timestamp and reviewer ID |

Key rules:
- Students only see jobs that are approved **and** belong to an approved company.
- Eligibility is evaluated server-side in `POST /student/apply/:id` (CGPA and branch). Ineligible students are blocked with an explanation.
- Recruiters can update only applications belonging to their own jobs.
- Admin accounts cannot be self-registered (seeded only).

## Local setup
Requires Node.js 18+.
```bash
git clone <your-repo-url> && cd campus-placement-portal
npm install
npm run seed      # creates portal.db with sample data
npm start         # http://localhost:3000
```
Reset the database: `npm run reset`
Optional env vars: `PORT`, `SESSION_SECRET`, `DB_FILE`.

## Mock credentials
| Role | Email | Password |
|---|---|---|
| Admin | admin@campus.edu | Admin@123 |
| Recruiter (approved company) | recruiter@acme.com | Recruiter@123 |
| Recruiter (company pending) | hr@newco.com | Recruiter@123 |
| Student (CGPA 8.6, CSE) | alice@campus.edu | Student@123 |
| Student (CGPA 6.2, ECE) | bob@campus.edu | Student@123 |

## Suggested demo flow
1. Log in as **bob** → Openings. "Software Engineer" shows Not eligible (CGPA 6.2 < 8.0, branch ECE). Clicking Apply is also rejected by the server.
2. Log in as **alice** → apply to both jobs → My Applications.
3. Log in as **recruiter@acme.com** → job → Applicants → tick one or several → change status. Alice's page updates.
4. Log in as **admin** → approve NewCo Labs and the pending "Data Analyst Intern" → Audit Log.

## Known limitations (future work)
No CSRF tokens, rate limiting, password reset or email notifications. Sessions use the in-memory store. Recruiters have one company per account, and editing a company does not re-trigger approval. Use HTTPS and a persistent session store in production.

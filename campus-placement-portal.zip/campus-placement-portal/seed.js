const bcrypt = require('bcryptjs'), db = require('./db');
const u = db.prepare('INSERT OR IGNORE INTO users(email,password_hash,name,role) VALUES(?,?,?,?)');
const mk = (e, p, n, r) => { u.run(e, bcrypt.hashSync(p, 10), n, r); return db.prepare('SELECT id FROM users WHERE email=?').get(e).id; };
const admin = mk('admin@campus.edu', 'Admin@123', 'Placement Officer', 'admin');
const r1 = mk('recruiter@acme.com', 'Recruiter@123', 'Acme HR', 'recruiter');
const r2 = mk('hr@newco.com', 'Recruiter@123', 'NewCo HR', 'recruiter');
const s1 = mk('alice@campus.edu', 'Student@123', 'Alice Rao', 'student');
const s2 = mk('bob@campus.edu', 'Student@123', 'Bob Iyer', 'student');
const sp = db.prepare('INSERT OR REPLACE INTO student_profiles VALUES(?,?,?,?,?)');
sp.run(s1, 'CSE', 8.6, 2027, 'https://example.com/alice.pdf');
sp.run(s2, 'ECE', 6.2, 2027, 'https://example.com/bob.pdf');
const c = db.prepare('INSERT OR IGNORE INTO companies(user_id,name,description,website,status,reviewed_by,reviewed_at) VALUES(?,?,?,?,?,?,CURRENT_TIMESTAMP)');
c.run(r1, 'Acme Technologies', 'Product engineering company', 'https://acme.example', 'approved', admin);
c.run(r2, 'NewCo Labs', 'Early-stage startup (awaiting approval)', 'https://newco.example', 'pending', null);
const cid = db.prepare('SELECT id FROM companies WHERE user_id=?').get(r1).id;
if (!db.prepare('SELECT 1 FROM jobs').get()) {
  const j = db.prepare('INSERT INTO jobs(company_id,title,description,min_cgpa,allowed_branches,status,reviewed_by,reviewed_at) VALUES(?,?,?,?,?,?,?,CURRENT_TIMESTAMP)');
  j.run(cid, 'Software Engineer', 'Backend development role', 8.0, 'CSE,IT', 'approved', admin);
  j.run(cid, 'Graduate Trainee', 'Open to most branches', 6.0, 'CSE,IT,ECE,EEE', 'approved', admin);
  j.run(cid, 'Data Analyst Intern', 'Awaiting admin review', 7.0, 'CSE,IT', 'pending', null);
}
console.log('Seed complete.');

const Database = require('better-sqlite3');
const db = new Database(process.env.DB_FILE || 'portal.db');
db.pragma('foreign_keys = ON');
db.exec(`
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, email TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, name TEXT NOT NULL, role TEXT NOT NULL CHECK(role IN('student','recruiter','admin')));
CREATE TABLE IF NOT EXISTS student_profiles(user_id INTEGER PRIMARY KEY REFERENCES users(id), branch TEXT, cgpa REAL, grad_year INTEGER, resume_url TEXT);
CREATE TABLE IF NOT EXISTS companies(id INTEGER PRIMARY KEY, user_id INTEGER UNIQUE REFERENCES users(id), name TEXT, description TEXT, website TEXT, status TEXT DEFAULT 'pending', reviewed_by INTEGER REFERENCES users(id), reviewed_at TEXT);
CREATE TABLE IF NOT EXISTS jobs(id INTEGER PRIMARY KEY, company_id INTEGER REFERENCES companies(id), title TEXT, description TEXT, min_cgpa REAL DEFAULT 0, allowed_branches TEXT DEFAULT '', status TEXT DEFAULT 'pending', reviewed_by INTEGER REFERENCES users(id), reviewed_at TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS applications(id INTEGER PRIMARY KEY, job_id INTEGER REFERENCES jobs(id), student_id INTEGER REFERENCES users(id), status TEXT DEFAULT 'Applied', created_at TEXT DEFAULT CURRENT_TIMESTAMP, updated_at TEXT DEFAULT CURRENT_TIMESTAMP, UNIQUE(job_id, student_id));
CREATE TABLE IF NOT EXISTS admin_logs(id INTEGER PRIMARY KEY, admin_id INTEGER REFERENCES users(id), entity_type TEXT, entity_id INTEGER, action TEXT, note TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
`);
module.exports = db;

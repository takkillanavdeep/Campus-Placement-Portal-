const express = require('express'), session = require('express-session'), bcrypt = require('bcryptjs'), db = require('./db');
const app = express();
app.use(express.urlencoded({ extended: false }));
app.use(session({ secret: process.env.SESSION_SECRET || 'dev-secret-change-me', resave: false, saveUninitialized: false, cookie: { httpOnly: true, sameSite: 'lax' } }));

const STATUSES = ['Applied', 'Under Review', 'Shortlisted', 'Interview', 'Offered', 'Rejected'];
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const NAV = { student: [['/student/jobs', 'Openings'], ['/student/applications', 'My Applications'], ['/student/profile', 'Profile']], recruiter: [['/recruiter', 'Dashboard']], admin: [['/admin', 'Approvals'], ['/admin/logs', 'Audit Log']] };

const page = (req, title, body, refresh) => {
  const u = req.session.user, flash = req.session.flash; delete req.session.flash;
  return `<!doctype html><html><head><meta charset="utf-8"><title>${esc(title)}</title>${refresh ? `<meta http-equiv="refresh" content="${refresh}">` : ''}
<meta name="viewport" content="width=device-width,initial-scale=1"><style>
body{font:15px system-ui,sans-serif;margin:0;background:#f4f5f7;color:#222}nav{background:#1f3a5f;padding:12px 24px;display:flex;gap:18px;align-items:center}nav a,nav span{color:#fff;text-decoration:none}nav .sp{flex:1}
main{max-width:980px;margin:24px auto;padding:0 16px}.card{background:#fff;border-radius:8px;padding:16px;margin:12px 0;box-shadow:0 1px 3px #0002}
table{width:100%;border-collapse:collapse}td,th{padding:8px;border-bottom:1px solid #eee;text-align:left}input,select,textarea{padding:7px;margin:3px 0;width:100%;box-sizing:border-box}
button{background:#1f3a5f;color:#fff;border:0;padding:8px 14px;border-radius:5px;cursor:pointer}button.no{background:#b3261e}.msg{padding:10px 14px;border-radius:6px;background:#fff3cd;margin:12px 0}
.tag{padding:2px 8px;border-radius:10px;background:#e3e8ef;font-size:12px}.ok{color:#1b7f3b}.bad{color:#b3261e}</style></head><body>
<nav><b style="color:#fff">Campus Placement Portal</b>${u ? NAV[u.role].map(([h, t]) => `<a href="${h}">${t}</a>`).join('') : ''}<span class="sp"></span>
${u ? `<span>${esc(u.name)} (${u.role})</span><form method="post" action="/logout" style="margin:0"><button>Logout</button></form>` : ''}</nav>
<main>${flash ? `<div class="msg">${flash}</div>` : ''}<h2>${esc(title)}</h2>${body}</main></body></html>`;
};
const need = role => (req, res, next) => {
  if (!req.session.user) return res.redirect('/login');
  if (req.session.user.role !== role) return res.status(403).send(page(req, 'Forbidden', '<p>Your role cannot access this page.</p>'));
  next();
};
const back = (req, res, msg, to) => { req.session.flash = msg; res.redirect(to); };
const home = u => ({ student: '/student/jobs', recruiter: '/recruiter', admin: '/admin' }[u.role]);

// Server-side eligibility rules (single source of truth)
function eligibility(p, job) {
  const why = [];
  if (!p || p.cgpa == null || !p.branch) return ['Complete your profile (branch and CGPA) before applying.'];
  if (p.cgpa < job.min_cgpa) why.push(`Your CGPA (${p.cgpa}) is below the required minimum (${job.min_cgpa}).`);
  const allowed = job.allowed_branches.split(',').map(s => s.trim().toLowerCase()).filter(Boolean);
  if (allowed.length && !allowed.includes(p.branch.toLowerCase())) why.push(`Your branch (${esc(p.branch)}) is not in the allowed list: ${esc(job.allowed_branches)}.`);
  return why;
}

// ---------- Auth ----------
app.get('/', (req, res) => res.redirect(req.session.user ? home(req.session.user) : '/login'));
app.get('/login', (req, res) => res.send(page(req, 'Sign in', `<div class="card"><form method="post"><input name="email" type="email" placeholder="Email" required><input name="password" type="password" placeholder="Password" required><button>Login</button></form><p>New here? <a href="/register">Register</a></p></div>`)));
app.post('/login', (req, res) => {
  const u = db.prepare('SELECT * FROM users WHERE email=?').get(String(req.body.email).toLowerCase());
  if (!u || !bcrypt.compareSync(req.body.password, u.password_hash)) return back(req, res, 'Invalid credentials.', '/login');
  req.session.user = { id: u.id, name: u.name, role: u.role }; res.redirect(home(u));
});
app.get('/register', (req, res) => res.send(page(req, 'Register', `<div class="card"><form method="post"><input name="name" placeholder="Full name" required><input name="email" type="email" placeholder="Email" required><input name="password" type="password" minlength="8" placeholder="Password (min 8)" required><select name="role"><option value="student">Student</option><option value="recruiter">Company Recruiter</option></select><button>Create account</button></form></div>`)));
app.post('/register', (req, res) => {
  const { name, email, password, role } = req.body;
  if (!['student', 'recruiter'].includes(role)) return back(req, res, 'Invalid role.', '/register'); // admins can't self-register
  try { db.prepare('INSERT INTO users(email,password_hash,name,role) VALUES(?,?,?,?)').run(email.toLowerCase(), bcrypt.hashSync(password, 10), name, role); }
  catch { return back(req, res, 'Email already registered.', '/register'); }
  back(req, res, 'Account created. Please sign in.', '/login');
});
app.post('/logout', (req, res) => req.session.destroy(() => res.redirect('/login')));

// ---------- Student ----------
app.get('/student/jobs', need('student'), (req, res) => {
  const p = db.prepare('SELECT * FROM student_profiles WHERE user_id=?').get(req.session.user.id);
  const jobs = db.prepare(`SELECT j.*,c.name company FROM jobs j JOIN companies c ON c.id=j.company_id WHERE j.status='approved' AND c.status='approved' ORDER BY j.id DESC`).all();
  const applied = new Set(db.prepare('SELECT job_id FROM applications WHERE student_id=?').all(req.session.user.id).map(a => a.job_id));
  res.send(page(req, 'Approved Openings', jobs.map(j => { const why = eligibility(p, j);
    return `<div class="card"><b>${esc(j.title)}</b> — ${esc(j.company)}<p>${esc(j.description)}</p><p>Min CGPA: <b>${j.min_cgpa}</b> · Branches: ${esc(j.allowed_branches) || 'All'}</p>
    ${applied.has(j.id) ? '<span class="tag">Already applied</span>' : why.length ? `<p class="bad">Not eligible: ${why.join(' ')}</p>` : '<span class="ok">You are eligible.</span>'}
    ${applied.has(j.id) ? '' : `<form method="post" action="/student/apply/${j.id}"><button>Apply</button></form>`}</div>`; }).join('') || '<p>No openings yet.</p>'));
});
app.get('/student/profile', need('student'), (req, res) => {
  const p = db.prepare('SELECT * FROM student_profiles WHERE user_id=?').get(req.session.user.id) || {};
  res.send(page(req, 'My Profile', `<div class="card"><form method="post">Branch<input name="branch" value="${esc(p.branch)}" required>CGPA (0-10)<input name="cgpa" type="number" step="0.01" min="0" max="10" value="${esc(p.cgpa)}" required>Graduation year<input name="grad_year" type="number" value="${esc(p.grad_year)}" required>Resume link<input name="resume_url" type="url" value="${esc(p.resume_url)}"><button>Save</button></form></div>`));
});
app.post('/student/profile', need('student'), (req, res) => {
  const { branch, cgpa, grad_year, resume_url } = req.body, g = parseFloat(cgpa);
  if (!(g >= 0 && g <= 10)) return back(req, res, 'CGPA must be between 0 and 10.', '/student/profile');
  db.prepare('INSERT OR REPLACE INTO student_profiles VALUES(?,?,?,?,?)').run(req.session.user.id, branch.trim(), g, parseInt(grad_year), resume_url);
  back(req, res, 'Profile saved.', '/student/profile');
});
app.post('/student/apply/:id', need('student'), (req, res) => {
  const j = db.prepare(`SELECT j.* FROM jobs j JOIN companies c ON c.id=j.company_id WHERE j.id=? AND j.status='approved' AND c.status='approved'`).get(req.params.id);
  if (!j) return back(req, res, 'This opening is not available.', '/student/jobs');
  const why = eligibility(db.prepare('SELECT * FROM student_profiles WHERE user_id=?').get(req.session.user.id), j);
  if (why.length) return back(req, res, `<b>Application blocked.</b> ${why.join(' ')}`, '/student/jobs');
  try { db.prepare('INSERT INTO applications(job_id,student_id) VALUES(?,?)').run(j.id, req.session.user.id); back(req, res, 'Application submitted!', '/student/applications'); }
  catch { back(req, res, 'You have already applied to this job.', '/student/applications'); }
});
app.get('/student/applications', need('student'), (req, res) => {
  const rows = db.prepare(`SELECT a.*,j.title,c.name company FROM applications a JOIN jobs j ON j.id=a.job_id JOIN companies c ON c.id=j.company_id WHERE a.student_id=? ORDER BY a.updated_at DESC`).all(req.session.user.id);
  const step = s => STATUSES.slice(0, 5).map((x, i) => `<span class="tag" style="${x === s ? 'background:#1f3a5f;color:#fff' : ''}">${x}</span>`).join(' → ') + (s === 'Rejected' ? ' <span class="tag bad">Rejected</span>' : '');
  res.send(page(req, 'My Applications (auto-refreshes every 15s)', rows.map(a => `<div class="card"><b>${esc(a.title)}</b> — ${esc(a.company)}<p>${step(a.status)}</p><small>Applied ${a.created_at} · Updated ${a.updated_at} (UTC)</small></div>`).join('') || '<p>No applications yet.</p>', 15));
});

// ---------- Recruiter ----------
const myCompany = req => db.prepare('SELECT * FROM companies WHERE user_id=?').get(req.session.user.id);
app.get('/recruiter', need('recruiter'), (req, res) => {
  const c = myCompany(req); let body = '';
  body += `<div class="card"><h3>Company profile ${c ? `<span class="tag">${c.status}</span>` : ''}</h3><form method="post" action="/recruiter/company">Name<input name="name" value="${esc(c?.name)}" required>Description<textarea name="description">${esc(c?.description)}</textarea>Website<input name="website" value="${esc(c?.website)}"><button>${c ? 'Update' : 'Submit for approval'}</button></form></div>`;
  if (c?.status === 'approved') {
    body += `<div class="card"><h3>Publish a job</h3><form method="post" action="/recruiter/jobs"><input name="title" placeholder="Title" required><textarea name="description" placeholder="Description"></textarea>Minimum CGPA<input name="min_cgpa" type="number" step="0.01" min="0" max="10" value="0" required>Allowed branches (comma-separated, blank = all)<input name="allowed_branches" placeholder="CSE,IT,ECE"><button>Submit for approval</button></form></div>`;
    const jobs = db.prepare('SELECT j.*,(SELECT COUNT(*) FROM applications WHERE job_id=j.id) n FROM jobs j WHERE company_id=? ORDER BY id DESC').all(c.id);
    body += `<div class="card"><h3>Your postings</h3><table><tr><th>Title</th><th>Criteria</th><th>Status</th><th>Applicants</th></tr>${jobs.map(j => `<tr><td>${esc(j.title)}</td><td>CGPA ≥ ${j.min_cgpa}; ${esc(j.allowed_branches) || 'All'}</td><td>${j.status}</td><td><a href="/recruiter/jobs/${j.id}">${j.n} view</a></td></tr>`).join('')}</table></div>`;
  } else if (c) body += '<p class="msg">Job posting unlocks once the Placement Cell approves your company.</p>';
  res.send(page(req, 'Recruiter Dashboard', body));
});
app.post('/recruiter/company', need('recruiter'), (req, res) => {
  const { name, description, website } = req.body;
  if (myCompany(req)) db.prepare(`UPDATE companies SET name=?,description=?,website=? WHERE user_id=?`).run(name, description, website, req.session.user.id);
  else db.prepare('INSERT INTO companies(user_id,name,description,website) VALUES(?,?,?,?)').run(req.session.user.id, name, description, website);
  back(req, res, 'Company profile saved.', '/recruiter');
});
app.post('/recruiter/jobs', need('recruiter'), (req, res) => {
  const c = myCompany(req); if (c?.status !== 'approved') return back(req, res, 'Company not approved yet.', '/recruiter');
  const b = req.body, m = parseFloat(b.min_cgpa);
  if (!(m >= 0 && m <= 10)) return back(req, res, 'Invalid CGPA threshold.', '/recruiter');
  db.prepare('INSERT INTO jobs(company_id,title,description,min_cgpa,allowed_branches) VALUES(?,?,?,?,?)').run(c.id, b.title, b.description, m, b.allowed_branches.trim());
  back(req, res, 'Job submitted for admin approval.', '/recruiter');
});
app.get('/recruiter/jobs/:id', need('recruiter'), (req, res) => {
  const j = db.prepare('SELECT j.* FROM jobs j JOIN companies c ON c.id=j.company_id WHERE j.id=? AND c.user_id=?').get(req.params.id, req.session.user.id);
  if (!j) return res.status(404).send(page(req, 'Not found', ''));
  const apps = db.prepare(`SELECT a.id,a.status,u.name,u.email,p.branch,p.cgpa,p.grad_year,p.resume_url FROM applications a JOIN users u ON u.id=a.student_id LEFT JOIN student_profiles p ON p.user_id=u.id WHERE a.job_id=?`).all(j.id);
  res.send(page(req, `Applicants — ${j.title}`, `<form method="post" action="/recruiter/applications/status"><input type="hidden" name="back" value="/recruiter/jobs/${j.id}"><div class="card"><table><tr><th></th><th>Candidate</th><th>Branch</th><th>CGPA</th><th>Year</th><th>Resume</th><th>Status</th></tr>
${apps.map(a => `<tr><td><input type="checkbox" name="ids" value="${a.id}" style="width:auto"></td><td>${esc(a.name)}<br><small>${esc(a.email)}</small></td><td>${esc(a.branch)}</td><td>${a.cgpa}</td><td>${a.grad_year}</td><td>${a.resume_url ? `<a href="${esc(a.resume_url)}" target="_blank" rel="noopener">Open</a>` : '-'}</td><td>${a.status}</td></tr>`).join('')}</table></div>
<p>Move selected (one or many) to: <select name="status" style="width:auto">${STATUSES.map(s => `<option>${s}</option>`).join('')}</select> <button>Update selected</button></p></form>`));
});
app.post('/recruiter/applications/status', need('recruiter'), (req, res) => { // single or batch
  const ids = [].concat(req.body.ids || []).map(Number).filter(Number.isInteger);
  if (!STATUSES.includes(req.body.status) || !ids.length) return back(req, res, 'Select applicants and a valid status.', req.body.back || '/recruiter');
  const st = db.prepare(`UPDATE applications SET status=?,updated_at=CURRENT_TIMESTAMP WHERE id=? AND job_id IN (SELECT j.id FROM jobs j JOIN companies c ON c.id=j.company_id WHERE c.user_id=?)`);
  let n = 0; db.transaction(() => ids.forEach(id => n += st.run(req.body.status, id, req.session.user.id).changes))();
  back(req, res, `${n} application(s) updated to "${req.body.status}".`, req.body.back || '/recruiter');
});

// ---------- Admin ----------
app.get('/admin', need('admin'), (req, res) => {
  const row = (t, id, title, sub) => `<div class="card"><b>${esc(title)}</b><br><small>${sub}</small><form method="post" action="/admin/review"><input type="hidden" name="type" value="${t}"><input type="hidden" name="id" value="${id}"><input name="note" placeholder="Note (optional)"><button name="decision" value="approved">Approve</button> <button class="no" name="decision" value="rejected">Reject</button></form></div>`;
  const cs = db.prepare(`SELECT * FROM companies WHERE status='pending'`).all();
  const js = db.prepare(`SELECT j.*,c.name company FROM jobs j JOIN companies c ON c.id=j.company_id WHERE j.status='pending'`).all();
  res.send(page(req, 'Pending Approvals', `<h3>Companies</h3>${cs.map(c => row('company', c.id, c.name, esc(c.description))).join('') || '<p>None pending.</p>'}<h3>Job postings</h3>${js.map(j => row('job', j.id, `${j.title} @ ${j.company}`, `CGPA ≥ ${j.min_cgpa}; ${esc(j.allowed_branches) || 'All'}`)).join('') || '<p>None pending.</p>'}`));
});
app.post('/admin/review', need('admin'), (req, res) => {
  const { type, id, decision, note } = req.body, table = { company: 'companies', job: 'jobs' }[type];
  if (!table || !['approved', 'rejected'].includes(decision)) return back(req, res, 'Invalid request.', '/admin');
  db.transaction(() => {
    const r = db.prepare(`UPDATE ${table} SET status=?,reviewed_by=?,reviewed_at=CURRENT_TIMESTAMP WHERE id=? AND status='pending'`).run(decision, req.session.user.id, id);
    if (r.changes) db.prepare('INSERT INTO admin_logs(admin_id,entity_type,entity_id,action,note) VALUES(?,?,?,?,?)').run(req.session.user.id, type, id, decision, note || '');
  })();
  back(req, res, `Marked ${type} #${id} as ${decision}.`, '/admin');
});
app.get('/admin/logs', need('admin'), (req, res) => {
  const logs = db.prepare(`SELECT l.*,u.email,u.name FROM admin_logs l JOIN users u ON u.id=l.admin_id ORDER BY l.id DESC`).all();
  res.send(page(req, 'Admin Audit Log', `<div class="card"><table><tr><th>Time (UTC)</th><th>Reviewer ID</th><th>Reviewer</th><th>Entity</th><th>Action</th><th>Note</th></tr>${logs.map(l => `<tr><td>${l.created_at}</td><td>${l.admin_id}</td><td>${esc(l.email)}</td><td>${l.entity_type} #${l.entity_id}</td><td>${l.action}</td><td>${esc(l.note)}</td></tr>`).join('')}</table></div>`));
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Portal running at http://localhost:${PORT}`));
